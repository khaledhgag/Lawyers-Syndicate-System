const t=r=>{if(!r)return"";try{return new Date(r).toLocaleDateString("ar-EG",{year:"numeric",month:"long",day:"numeric"})}catch{return""}},e=r=>{if(!r)return"";try{return new Date(r).toLocaleString("ar-EG",{year:"numeric",month:"short",day:"numeric",hour:"2-digit",minute:"2-digit"})}catch{return""}};export{e as a,t as f};
//# sourceMappingURL=format-Bc9kXPNo.js.map
